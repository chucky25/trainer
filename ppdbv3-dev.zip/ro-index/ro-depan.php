
<section class="col-sm-12">
<div class="jumbotron">
        <h2>Selamat Datang di Halaman <?php echo "$row[nama_sekolah]";?></h2>
        <p style="font-size: 18px;">Halaman ini merupakan  resmi Pendaftaran Peserta Didik Baru  <?php echo "$row[nama_sekolah]";?>. Untuk melakukan pendaftaran silahkan klik menu daftar atau jika sudah mendaftar silahkan cetak bukti pendaftarannya melalui menu print. Untuk informasi lebih lanjut bisa menghubungi Panitia PPDB melalui No.Tlp/HP berikut <?php echo "$row[telephone_sekolah]";?> </p>
</div>
</section>


