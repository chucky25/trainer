
<br/>
<?php 
include('../ro-databases/koneksi.php');
include('../ro-query/ro-update-siswa.php');
?>
<!-- CEGAH BY PASS PERHALAMAN -->
<?php include('ro-session-nobypass.php'); ?>
<div class="col-lg-12">
<div class="row">
<?php 
include('../ro-includes/variabel-siswa-error.php'); 
?>
</div>
</div>
<!-- /.row (nested) -->
