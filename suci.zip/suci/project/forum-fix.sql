/*
SQLyog Ultimate v11.33 (32 bit)
MySQL - 10.1.19-MariaDB : Database - forum
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`forum` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `forum`;

/*Table structure for table `signup` */

DROP TABLE IF EXISTS `signup`;

CREATE TABLE `signup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `signup` */

insert  into `signup`(`id`,`nama`,`email`,`password`) values (1,'nanda','nandasolong@gmail.com','$2y$10$G/o1ueERRZoCxOOV5gHatevCBFRfiEGVqHUX/6vEKfzrWsMepIUPC'),(2,'nanda','nandakrisbianto808@gmail.com','$2y$10$Gu62kJkpfbgdRzwN1L6GXO9YaRtxRE44lDwDxNT82wfCmzwGNOEEu');

/*Table structure for table `topic` */

DROP TABLE IF EXISTS `topic`;

CREATE TABLE `topic` (
  `id_topic` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `sub_category` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `privacy` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_topic`),
  KEY `id1` (`id`),
  CONSTRAINT `id1` FOREIGN KEY (`id`) REFERENCES `signup` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `topic` */

insert  into `topic`(`id_topic`,`id`,`title`,`category`,`sub_category`,`description`,`privacy`) values (1,1,'aku suka kamu','cinta','galau','harusnya aku yang disana dampingimu dan bukan dia harusnay aku yang kau cinta dan bukan diaa','anta kau dan aku');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
