<?php 

$conn = mysqli_connect("localhost","root","","forum");

if (!$conn) {
	die("koneksi tidak Berhasil");
	mysqli_close($conn);
}

function alert($pesan,$location){
	echo "
	<script>
	alert('$pesan');
	document.location.href='$location';
	</script>
	";
}

function register($data){
	global $conn;
	$nama = $data["name"];
	$email = strtolower(stripslashes($data["email"]));
	$password = mysqli_real_escape_string($conn,$data["password"]);
	$password2 = mysqli_real_escape_string($conn,$data["password2"]);

	$result = mysqli_query($conn," SELECT email FROM user WHERE email = '$email' ");
	if (isset($_POST['daftar'])) {
		# code...
	if (mysqli_fetch_assoc($result)) {
		# code...
		alert('NAMA USER TELAH ADA COBA CARI NAMA LAIN','#');
		return false;
	}

	if($password !== $password2){
		alert('PASSWORD 1 DAN 2 TIDAK SAMA','register.php');
		return false;
	}

	$password = password_hash($password, PASSWORD_DEFAULT);
	mysqli_query($conn,"INSERT INTO signup(nama,email,password) VALUES('$nama','$email','$password')");
	return mysqli_affected_rows($conn);
	
}
}

function topik($query){
	$title = $query['title'];
	$category = $query['category'];
	$sub = $query['sub-category'];
	$desc = $query['description'];
}

 ?>