<?php 

require 'funtion.php';

if (isset($_POST['send'])) {
	$title = $_POST['title'];
	$category = $_POST['category'];
	$sub = $_POST['sub-category'];
	$desc = $_POST['description'];
}

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>New Topik</title>
</head>
<body>
	<form action="post">
		<label for="title">TITLE</label>
		<input type="text" name="title"> <br>
		<label for="category">CATEGORY</label>
		<input type="text" name="category"> <br>
		<label for="sub-category">SUB CATEGORY</label>
		<input type="text" name="sub-category"> <br>
		<label for="description"></label>
		<input type="text" name="description">
		<button type="submit" name="send">KIRIM</button>
	</form>
</body>
</html>