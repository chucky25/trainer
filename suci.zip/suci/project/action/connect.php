<?php

$con = mysqli_connect("localhost", "root", "", "projectweb");
// mengecek koneksi
if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
