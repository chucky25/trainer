<html>
<head>
  <title>Register berhasil - Warunk Coding</tittle>
</head>

<body>
  <?php
  session_start();
  include "connect.php";

  $no;
  $nama = $_POST['name'];
  $email = $_POST['email'];
  $passwd = $_POST['password'];
  $query = "insert into pendaftaran values ('$no','$nama','$email','$passwd')";
  $exe=mysql_query($query);
  alert ("Data berhasil disimpan. <br> Silahkan login ke akun anda");

  //bikin notif alert regist berhasil
  //pas di klik ok kehalaman login

  ?>

  <script>
  alert("Data berhasil disimpan")
  </script>
</body>

</html>
