<?php 
session_start();
if (!isset($_SESSION['login'])) {
	# code...
	header('Location: login.php');
	exit;
}
require 'koneksi.php';

$result = datakeuangan("SELECT * FROM data_keuangan");
if (isset($_GET['edit'])) {
	$id=$_GET['edit'];
	$result = datakeuangan("SELECT * FROM data_keuangan WHERE id = '$id'");
	$kondisi = true;
}

if (isset($_POST['ubah'])) {
	if (ubahkeu($data)>0) {
		# code...
		echo "
			<script>
			 	alert('BERHASIL DI GANTI');
			 	document.location.href='inpkeuangan.php';
			 </script>
 ";
		return false;
	}
	}

if (isset($_POST['inputdata'])) {
	# code...

$jumlah= $_POST['input'];
$keterangan = $_POST['keterangan'];
$angkatan = $_POST['angkatan'];

$query = input("INSERT INTO data_keuangan VALUES ('','$jumlah','$keterangan','$angkatan')");

if (input($code)>0) {
	# code...
	echo "
	<script>
	alert('BERHASIL INPUT DATA');
	</script>
	";
	header('Location:inpkeuangan.php');
}
}

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>DATA SISWA</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
	<!-- Just an image -->
<!-- Image and text -->
<nav class="navbar navbar-light bg-primary">
  <a class="navbar-brand text-white" href="#">PANEL ADMIN
  </a>
</nav>
	<div class="row no-gutters">
		<div class="col col-md-3 col-lg-3">
			<ul class="nav flex-column bg-dark pt-4 pb-4 pr-4 pl-4">
  <li class="nav-item mt-1 mb-1">
  	<center>
  	<img style="border-radius: 50%;" src="assets/img/data-diri.png"></center>
    <h5 class="text-white text-center pt-2" >DASHBOARD ADMIN</h5><hr class="bg-secondary"></hr>
  </li>
  <li class="nav-item mt-1 mb-1">
    <a class="nav-link text-white" href="datasiswa.php"><span style="margin-right: 15px;"><svg class="svg-icon" viewBox="0 0 20 20">
							<path d="M15.573,11.624c0.568-0.478,0.947-1.219,0.947-2.019c0-1.37-1.108-2.569-2.371-2.569s-2.371,1.2-2.371,2.569c0,0.8,0.379,1.542,0.946,2.019c-0.253,0.089-0.496,0.2-0.728,0.332c-0.743-0.898-1.745-1.573-2.891-1.911c0.877-0.61,1.486-1.666,1.486-2.812c0-1.79-1.479-3.359-3.162-3.359S4.269,5.443,4.269,7.233c0,1.146,0.608,2.202,1.486,2.812c-2.454,0.725-4.252,2.998-4.252,5.685c0,0.218,0.178,0.396,0.395,0.396h16.203c0.218,0,0.396-0.178,0.396-0.396C18.497,13.831,17.273,12.216,15.573,11.624 M12.568,9.605c0-0.822,0.689-1.779,1.581-1.779s1.58,0.957,1.58,1.779s-0.688,1.779-1.58,1.779S12.568,10.427,12.568,9.605 M5.06,7.233c0-1.213,1.014-2.569,2.371-2.569c1.358,0,2.371,1.355,2.371,2.569S8.789,9.802,7.431,9.802C6.073,9.802,5.06,8.447,5.06,7.233 M2.309,15.335c0.202-2.649,2.423-4.742,5.122-4.742s4.921,2.093,5.122,4.742H2.309z M13.346,15.335c-0.067-0.997-0.382-1.928-0.882-2.732c0.502-0.271,1.075-0.429,1.686-0.429c1.828,0,3.338,1.385,3.535,3.161H13.346z"></path>
						</svg></span>DATA SISWA</a><hr class="bg-secondary"></hr>
  </li>
  <li class="nav-item mt-1 mb-1">
    <a class="nav-link text-white" href="tambah.php"><span style="margin-right: 15px;"><svg class="svg-icon" viewBox="0 0 20 20">
							<path fill="none" d="M19.404,6.65l-5.998-5.996c-0.292-0.292-0.765-0.292-1.056,0l-2.22,2.22l-8.311,8.313l-0.003,0.001v0.003l-0.161,0.161c-0.114,0.112-0.187,0.258-0.21,0.417l-1.059,7.051c-0.035,0.233,0.044,0.47,0.21,0.639c0.143,0.14,0.333,0.219,0.528,0.219c0.038,0,0.073-0.003,0.111-0.009l7.054-1.055c0.158-0.025,0.306-0.098,0.417-0.211l8.478-8.476l2.22-2.22C19.695,7.414,19.695,6.941,19.404,6.65z M8.341,16.656l-0.989-0.99l7.258-7.258l0.989,0.99L8.341,16.656z M2.332,15.919l0.411-2.748l4.143,4.143l-2.748,0.41L2.332,15.919z M13.554,7.351L6.296,14.61l-0.849-0.848l7.259-7.258l0.423,0.424L13.554,7.351zM10.658,4.457l0.992,0.99l-7.259,7.258L3.4,11.715L10.658,4.457z M16.656,8.342l-1.517-1.517V6.823h-0.003l-0.951-0.951l-2.471-2.471l1.164-1.164l4.942,4.94L16.656,8.342z"></path>
						</svg></span>TAMBAH DATA</a><hr class="bg-secondary"></hr>
  </li>
   <li class="nav-item mt-1 mb-1">
    <a class="nav-link text-white" href="#"><span style="margin-right: 15px;"><svg class="svg-icon" viewBox="0 0 20 20">
							<path fill="none" d="M4.319,8.257c-0.242,0-0.438,0.196-0.438,0.438c0,0.243,0.196,0.438,0.438,0.438c0.242,0,0.438-0.196,0.438-0.438C4.757,8.454,4.561,8.257,4.319,8.257 M7.599,10.396c0,0.08,0.017,0.148,0.05,0.204c0.034,0.056,0.076,0.104,0.129,0.144c0.051,0.04,0.112,0.072,0.182,0.097c0.041,0.015,0.068,0.028,0.098,0.04V9.918C7.925,9.927,7.832,9.958,7.747,10.02C7.648,10.095,7.599,10.22,7.599,10.396 M15.274,6.505H1.252c-0.484,0-0.876,0.392-0.876,0.876v7.887c0,0.484,0.392,0.876,0.876,0.876h14.022c0.483,0,0.876-0.392,0.876-0.876V7.381C16.15,6.897,15.758,6.505,15.274,6.505M1.69,7.381c0.242,0,0.438,0.196,0.438,0.438S1.932,8.257,1.69,8.257c-0.242,0-0.438-0.196-0.438-0.438S1.448,7.381,1.69,7.381M1.69,15.269c-0.242,0-0.438-0.196-0.438-0.438s0.196-0.438,0.438-0.438c0.242,0,0.438,0.195,0.438,0.438S1.932,15.269,1.69,15.269M14.836,15.269c-0.242,0-0.438-0.196-0.438-0.438s0.196-0.438,0.438-0.438s0.438,0.195,0.438,0.438S15.078,15.269,14.836,15.269M15.274,13.596c-0.138-0.049-0.283-0.08-0.438-0.08c-0.726,0-1.314,0.589-1.314,1.314c0,0.155,0.031,0.301,0.08,0.438H2.924c0.049-0.138,0.081-0.283,0.081-0.438c0-0.726-0.589-1.314-1.315-1.314c-0.155,0-0.3,0.031-0.438,0.08V9.053C1.39,9.103,1.535,9.134,1.69,9.134c0.726,0,1.315-0.588,1.315-1.314c0-0.155-0.032-0.301-0.081-0.438h10.678c-0.049,0.137-0.08,0.283-0.08,0.438c0,0.726,0.589,1.314,1.314,1.314c0.155,0,0.301-0.031,0.438-0.081V13.596z M14.836,8.257c-0.242,0-0.438-0.196-0.438-0.438s0.196-0.438,0.438-0.438s0.438,0.196,0.438,0.438S15.078,8.257,14.836,8.257 M12.207,13.516c-0.242,0-0.438,0.196-0.438,0.438s0.196,0.438,0.438,0.438s0.438-0.196,0.438-0.438S12.449,13.516,12.207,13.516 M8.812,11.746c-0.059-0.043-0.126-0.078-0.199-0.104c-0.047-0.017-0.081-0.031-0.117-0.047v1.12c0.137-0.021,0.237-0.064,0.336-0.143c0.116-0.09,0.174-0.235,0.174-0.435c0-0.092-0.018-0.17-0.053-0.233C8.918,11.842,8.87,11.788,8.812,11.746 M18.78,3.875H4.757c-0.484,0-0.876,0.392-0.876,0.876V5.19c0,0.242,0.196,0.438,0.438,0.438c0.242,0,0.438-0.196,0.438-0.438V4.752H18.78v7.888h-1.315c-0.242,0-0.438,0.196-0.438,0.438c0,0.243,0.195,0.438,0.438,0.438h1.315c0.483,0,0.876-0.393,0.876-0.876V4.752C19.656,4.268,19.264,3.875,18.78,3.875 M8.263,8.257c-1.694,0-3.067,1.374-3.067,3.067c0,1.695,1.373,3.068,3.067,3.068c1.695,0,3.067-1.373,3.067-3.068C11.33,9.631,9.958,8.257,8.263,8.257 M9.488,12.543c-0.062,0.137-0.147,0.251-0.255,0.342c-0.108,0.092-0.234,0.161-0.378,0.209c-0.123,0.041-0.229,0.063-0.359,0.075v0.347H8.058v-0.347c-0.143-0.009-0.258-0.032-0.388-0.078c-0.152-0.053-0.281-0.128-0.388-0.226c-0.108-0.098-0.191-0.217-0.25-0.359c-0.059-0.143-0.087-0.307-0.083-0.492h0.575c-0.004,0.219,0.046,0.391,0.146,0.518c0.088,0.109,0.207,0.165,0.388,0.185v-1.211c-0.102-0.031-0.189-0.067-0.3-0.109c-0.136-0.051-0.259-0.116-0.368-0.198c-0.109-0.082-0.198-0.183-0.265-0.306c-0.067-0.123-0.101-0.275-0.101-0.457c0-0.159,0.031-0.298,0.093-0.419c0.062-0.121,0.146-0.222,0.252-0.303S7.597,9.57,7.735,9.527C7.85,9.491,7.944,9.474,8.058,9.468V9.134h0.438v0.333c0.114,0.005,0.207,0.021,0.319,0.054c0.134,0.04,0.251,0.099,0.351,0.179c0.099,0.079,0.178,0.18,0.237,0.303c0.059,0.122,0.088,0.265,0.088,0.427H8.916c-0.007-0.169-0.051-0.297-0.134-0.387C8.712,9.968,8.626,9.932,8.496,9.919v1.059c0.116,0.035,0.213,0.074,0.333,0.118c0.145,0.053,0.272,0.121,0.383,0.203c0.111,0.083,0.2,0.186,0.268,0.308c0.067,0.123,0.101,0.273,0.101,0.453C9.581,12.244,9.549,12.406,9.488,12.543"></path>
						</svg></span>INPUT KEUANGAN</a><hr class="bg-secondary"></hr>
  </li>
  <li class="nav-item mt-1 mb-1">
    <a class="nav-link text-white" href="inpkeuangan.php"><span style="margin-right: 15px"><svg class="svg-icon" viewBox="0 0 20 20">
							<path fill="none" d="M13.53,2.238c-0.389-0.164-0.844,0.017-1.01,0.41c-0.166,0.391,0.018,0.845,0.411,1.01
								c2.792,1.181,4.598,3.904,4.6,6.937c0,4.152-3.378,7.529-7.53,7.529c-4.151,0-7.529-3.377-7.529-7.529
								C2.469,7.591,4.251,4.878,7.01,3.683C7.401,3.515,7.58,3.06,7.412,2.67c-0.17-0.392-0.624-0.571-1.014-0.402
								c-3.325,1.44-5.472,4.708-5.47,8.327c0,5.002,4.069,9.071,9.071,9.071c5.003,0,9.073-4.07,9.073-9.071
								C19.07,6.939,16.895,3.659,13.53,2.238z"></path>
							<path fill="none" d="M9.999,7.616c0.426,0,0.771-0.345,0.771-0.771v-5.74c0-0.426-0.345-0.771-0.771-0.771
								c-0.427,0-0.771,0.345-0.771,0.771v5.74C9.228,7.271,9.573,7.616,9.999,7.616z"></path>
						</svg></span>LOGOUT</a><hr class="bg-secondary"></hr>
  </li>
</ul>
		</div>
		<div class="col">
			<div class="row">
				<div class="col">
					<div class="text-center pt-4 pb-4">
						<h1>DATA PEMBAYARAN TK SETYAWATI</h1>
					</div>
				</div>
			</div>
			<div class="container">
				<center>
					<div class="alert alert-primary" role="alert">
					  INPUT DATA KEUANGAN YANG HARUS DI BAYAR SISWA
					</div>
					<form class="mx-auto pb-4" method="post" action="">
						<div class="row justify-content-md-center">
						<div class="col-sm-3 my-1">
					      <label class="sr-only">Keterangan</label>
					      <input type="text" name="keterangan" class="form-control" placeholder="Keterangan Pembayaran">
						</div>
						<div class="col-sm-3 my-1">
					      <label class="sr-only">Jumlah</label>
					      <input type="number" name="input" class="form-control"placeholder="Jumlah yang harus dibayar">
						</div>
						<div class="col-sm-3 my-1">
					      <label class="sr-only">Jumlah</label>
					      <input type="number" name="angkatan" class="form-control"placeholder="angkatan..">
						</div>
						<div class="col-auto my-1">
					      <button type="submit" class="btn btn-primary" name="inputdata">Submit</button>
					    </div>
					    </div>
					</form>
			 	</center>
			<table class="table table-bordered">
			  <thead class="thead-dark text-center">
			    <tr>
			      <th scope="col">NO</th>
			      <th scope="col">KETERANGAN</th>
			      <th scope="col">JUMLAH</th>
			      <th scope="col">ANGKATAN</th>
			      <th scope="col">MENU</th>
			    </tr>
			  </thead>
			  <tbody>
			  	<?php if (isset($kondisi)) : ?>
			  	<?php $i=1; ?>
			  	<?php foreach ($result as $row) :?>
			    <tr>
			    	<form method="post">
			      <th scope="row"> <?= $i?></th>
			      <input type="hidden" value="<?= $row['id']; ?>" name="id">
			      <td><input type="text" value="<?= $row['ket']; ?>" name="editket"></td>
			      <td><input type="number" value="<?= $row['harga']; ?>" name="editharga"></td>
			      <td><input type="number" value="<?= $row['angakatan']; ?>" name="editharga"></td>
			      <td class="text-center">
			      	<button name="ubah" type="submit" class="btn btn-primary">UBAH</button>
			      	</form>
			      </td>
			    </tr>
			    	<?php $i++; ?>
					<?php 
					endforeach; 
						return false;
					endif; 
						?>
			  	<?php $i=1; ?>
			  	<?php foreach ($result as $row) :?>
			    <tr>
			      <th scope="row"> <?= $i?></th>
			      <td><?= $row['ket']; ?></td>
			      <td><?= $row['harga']; ?></td>
			      <td><?= $row['angakatan']; ?></td>
			      <td class="text-center"><a class="text-success" href="inpkeuangan.php?edit=<?php echo$row['id']; ?>">EDIT</a> | <a href="hapuskeu.php?id=<?php echo$row['id']; ?>" onclick="return confirm('YAKIN INGIN HAPUS ?')">HAPUS</a></td>
			    </tr>
			    <?php $i++; ?>
			<?php endforeach; ?>
			  </tbody>
</table>
			</div>
		</div>
	</div>
<script type="text/javascript" src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</body>
</html>