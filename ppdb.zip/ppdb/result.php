<?php 
require 'koneksi.php';
if (isset($_GET['cari'])) {
	# code...
	$nama = $_GET['namasiswa'];
	$data = pencarian("SELECT * FROM siswa WHERE nama_siswa LIKE '%$nama%' ");
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>HASIL PENCARIAN</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
	<nav class="navbar navbar-dark bg-dark">
  		<a class="navbar-brand text-white">TK SETYAWATI</a>
  		<form method="get" action="result.php" class="mx-auto col-12 col-md-8 col-sm-6" >
				<div class="input-group mb-3">
					<input type="text" class="form-control" placeholder="Username" autofocus="true" aria-label="Username" name="namasiswa" aria-describedby="basic-addon1">
					<div class="input-group-prepend">
					<button class="input-group-text" id="basic-addon1" name="cari"><svg style="max-width: 2em; max-height: 1.2em;" class="svg-icon" viewBox="0 0 20 20">
							<path d="M18.125,15.804l-4.038-4.037c0.675-1.079,1.012-2.308,1.01-3.534C15.089,4.62,12.199,1.75,8.584,1.75C4.815,1.75,1.982,4.726,2,8.286c0.021,3.577,2.908,6.549,6.578,6.549c1.241,0,2.417-0.347,3.44-0.985l4.032,4.026c0.167,0.166,0.43,0.166,0.596,0l1.479-1.478C18.292,16.234,18.292,15.968,18.125,15.804 M8.578,13.99c-3.198,0-5.716-2.593-5.733-5.71c-0.017-3.084,2.438-5.686,5.74-5.686c3.197,0,5.625,2.493,5.64,5.624C14.242,11.548,11.621,13.99,8.578,13.99 M16.349,16.981l-3.637-3.635c0.131-0.11,0.721-0.695,0.876-0.884l3.642,3.639L16.349,16.981z"></path>
						</svg>
						</button>
					</div>
				</div>
			</form>
</nav>
<div class="container">
	<?php foreach ($data as $row): ?>
	<div class="card">
	  <h5 class="card-header">HASIL PENCARIAN</h5>
  		<div class="card-body">
    	<h5 class="card-title"><?= $row['nama_siswa'];  ?></h5>
    	<p class="card-text"><span>NO INDUK SISWA : <?= $row['no_induk'];  ?></span>,<span>NAMA AYAH : <?= $row['nama_ayah'];  ?>,</span><span>NAMA AYAH : <?= $row['nama_ibu'];  ?>,</span><span>ANGKATAN : <?= $row['angkatan'];  ?></span></p>
	    <a href="cekadmin.php?id=<?= $row['id'];  ?>" class="btn btn-primary">CEK ADMINISTRASI</a>
  </div>
</div>
<?php endforeach ?>
</div>
</body>
</html>