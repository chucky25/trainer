<?php 
session_start();
if (!isset($_SESSION['login'])) {
	# code...
	header('Location: login.php');
	exit;
}
require 'koneksi.php';

if (isset($_POST['register'])) {
	# code...
	if ( registrasi($_POST)>0){
		# code...
		echo "
		<script>
		alert('USER BERHASIL DITAMBAHKAN');
		</script>

		";
	}
}


 ?>
<!DOCTYPE html>
<html>
<head>
	<title>REGISTRASI</title>
</head>
<body>
	<form method="post" action="">
		<ul>
			<li>
				<label>USERNAME</label>
				<input type="text" name="username">
			</li>
			<li>
				<label>PASSWORD</label>
				<input type="password" name="password">
			</li>
			<li>
				<label>PASSWORD VERIFY</label>
				<input type="password" name="password2">
			</li>
		</ul>
		<button name="register">REGISTRASI</button>
	</form>
</body>
</html>