<?php 
$conn = mysqli_connect("localhost","root","","tksetyawati");


function tampil($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}

	return $datasiswa;
}

function hapus($id)
{
	global $conn;
	$delete=("DELETE FROM siswa WHERE id=$id ");
	mysqli_query($conn,$delete);
	return mysqli_affected_rows($conn);
}

function hapuskeu($id)
{
	global $conn;
	$delete=("DELETE FROM data_keuangan WHERE id=$id ");
	mysqli_query($conn,$delete);
	return mysqli_affected_rows($conn);
}

function tambah($add){
	global $conn;
	$nmsiswa = htmlspecialchars($_POST['namasiswa']);
	$no_induk = htmlspecialchars($_POST['noinduk']);
	$angkatan = htmlspecialchars($_POST['angkatan']);
	$nmayah = htmlspecialchars($_POST['namaayah']);
	$nmibu = htmlspecialchars($_POST['namaibu']);
	$tambah = "
	INSERT INTO siswa VALUES 
	('','$nmsiswa','$no_induk','$angkatan','$nmayah','$nmibu')
	";
	mysqli_query($conn,$tambah);
	return mysqli_affected_rows($conn);
}

function edit($data){
	global $conn;
	$id = $_POST['id'];
	$nmsiswa = htmlspecialchars($_POST['namasiswa']);
	$no_induk = htmlspecialchars($_POST['noinduk']);
	$angkatan = htmlspecialchars($_POST['angkatan']);
	$nmayah = htmlspecialchars($_POST['namaayah']);
	$nmibu = htmlspecialchars($_POST['namaibu']);
	$tambah = "
	UPDATE siswa SET
	nama_siswa = '$nmsiswa',
	no_induk = '$no_induk',
	angkatan = '$angkatan',
	nama_ayah= '$nmayah',
	nama_ibu = '$nmibu' WHERE id=$id
	";
	mysqli_query($conn,$tambah);
	return mysqli_affected_rows($conn);
}

function registrasi($data){
	global $conn;

	$username = strtolower(stripslashes($data["username"]));
	$password = mysqli_real_escape_string($conn,$data["password"]);
	$password2 = mysqli_real_escape_string($conn,$data["password2"]);

	$result = mysqli_query($conn,"SELECT username FROM login WHERE username = '$username'");

	if (mysqli_fetch_assoc($result)) {
		# code...
		echo "
		<script>
		alert('USERNAME TELAH ADA');
		</script>
		";
		return false;
	}


	if ($password !== $password2) {
		# code...
		echo "
		<script>
		alert('PASSWORD 1 DAN 2 TIDAK SAMA');
		</script>
		";
		return false;
	}
	$password = password_hash($password, PASSWORD_DEFAULT);
	mysqli_query($conn,"INSERT INTO login VALUES('','$username','$password')");

	return mysqli_affected_rows($conn);
}

function input($code){
	global $conn;
	$input = mysqli_query($conn,$code);
	return mysqli_affected_rows($conn);	
}

function datakeuangan($query){
	global $conn;
	$result= mysqli_query($conn,$query);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}

function ubahkeu($data){
	global $conn;
	$id2 = $_POST['id'];
	$edithrg = (int)$_POST['editharga'];
	$ediket = $_POST['editket'];
	mysqli_query($conn,"
		UPDATE data_keuangan SET 
		harga = '$edithrg',
		ket = '$ediket' 
		WHERE id='$id2';
		");
	return mysqli_affected_rows($conn);
}

function pembayaran(){
	global $conn;
	$id2= $_POST['id'];
	$ket2 =$_POST['ket'];
	$jmlh =$_POST['uang'];
	$tgl =$_POST['tanggal'];
	mysqli_query($conn,"INSERT INTO pembayaran VALUES('','$id2','$ket2','$jmlh','$tgl')
	");
	return mysqli_affected_rows($conn);
}

function tampilPembayaran($code){
	global $conn;
	$for=mysqli_query($conn,$code);
	$result =[];
	while ($row= mysqli_fetch_assoc($for)) {
		# code...
		$result[]=$row;
	}
	return $result;
}

function hapuspembayaran($id){
	global $conn;
	mysqli_query($conn,"DELETE FROM pembayaran WHERE id_pembayaran=$id");
	return mysqli_affected_rows($conn);
}
function pencarian($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}

function total($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}

function total3($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}


function total2($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}

function total4($code){
	global $conn;
	$result= mysqli_query($conn,$code);
	$datasiswa=[];
	while ($datas=mysqli_fetch_assoc($result)) {
		$datasiswa[] = $datas;
	}
	return $datasiswa;
}


 ?>
