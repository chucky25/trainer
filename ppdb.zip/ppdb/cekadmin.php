<?php 
require 'koneksi.php';

$id=$_GET['id'];
$siswa = tampil("SELECT * FROM siswa WHERE id='$id'")[0];
$angkt = $siswa['angkatan'];
$data = pencarian("SELECT  * FROM pembayaran WHERE id = '$id'");
$code1 = total("SELECT SUM(harga) AS total FROM data_keuangan")[0];
$code2 = total3("SELECT SUM(uang) AS total FROM pembayaran WHERE id = '$id'")[0];
$data2 = total2("SELECT * FROM data_keuangan WHERE angakatan = '$angkt'");
$code3 = total4("SELECT siswa.id, (SUM(data_keuangan.harga)) - (SUM(pembayaran.uang)) AS total_all FROM siswa JOIN pembayaran USING(id) JOIN data_keuangan ON siswa.angkatan = data_keuangan.angakatan WHERE siswa.id='$id' AND pembayaran.id='$id'")[0];

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>HASIL PENCARIAN</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
	<nav class="navbar navbar-dark bg-dark">
  		<a class="navbar-brand text-white">TK SETYAWATI</a>
  		<form method="get" action="result.php" class="mx-auto col-12 col-md-8 col-sm-6" >
				<div class="input-group mb-3">
					<input type="text" class="form-control" placeholder="Username" autofocus="true" aria-label="Username" name="namasiswa" aria-describedby="basic-addon1">
					<div class="input-group-prepend">
					<button class="input-group-text" id="basic-addon1" name="cari"><svg style="max-width: 2em; max-height: 1.2em;" class="svg-icon" viewBox="0 0 20 20">
							<path d="M18.125,15.804l-4.038-4.037c0.675-1.079,1.012-2.308,1.01-3.534C15.089,4.62,12.199,1.75,8.584,1.75C4.815,1.75,1.982,4.726,2,8.286c0.021,3.577,2.908,6.549,6.578,6.549c1.241,0,2.417-0.347,3.44-0.985l4.032,4.026c0.167,0.166,0.43,0.166,0.596,0l1.479-1.478C18.292,16.234,18.292,15.968,18.125,15.804 M8.578,13.99c-3.198,0-5.716-2.593-5.733-5.71c-0.017-3.084,2.438-5.686,5.74-5.686c3.197,0,5.625,2.493,5.64,5.624C14.242,11.548,11.621,13.99,8.578,13.99 M16.349,16.981l-3.637-3.635c0.131-0.11,0.721-0.695,0.876-0.884l3.642,3.639L16.349,16.981z"></path>
						</svg>
						</button>
					</div>
				</div>
			</form>
</nav>
<div class="container mt-5 ">
	<div class="row MT-1">
		<div class="col">
			<label>NAMA SISWA</label>
			<input type="text" class="form-control" value=" <?= $siswa['nama_siswa'];  ?> " disabled="">
		</div>
		<div class="col">
			<label>ANGKATAN </label>
			<input type="text" class="form-control" value=" <?= $siswa['angkatan'];  ?> " disabled="">
		</div>
	</div>
	<div class="row mt-1">
		<div class="col">
			<label>NAMA AYAH</label>
			<input type="text" class="form-control" value=" <?= $siswa['nama_ayah'];  ?> " disabled="">
		</div>
		<div class="col">
			<label>NAMA IBU</label>
			<input type="text" class="form-control" value=" <?= $siswa['nama_ibu'];  ?> " disabled="">
		</div>
	</div>
		<table class="table table-bordered mt-4">
			  <thead class="thead-dark text-center">
			    <tr>
			      <th style="max-width: 80px !important;" scope="col">TANGGAL</th>
			      <th scope="col">PEMBAYARAN</th>
			      <th scope="col">JUMLAH</th>
			    </tr>
			  	</thead>
			  	<tbody>
			  		<?php foreach ($data as $rows): ?>
			    <tr>
			      <td class="text-center" style="max-width: 80px !important;"><?= $rows['tanggal']; ?></td>
			      <td><?= $rows['ket']; ?></td>
			      <td><?= $rows['uang']; ?></td>
			    </tr>
			    <?php endforeach; ?>
			    <tr>
			    	<td colspan="2"><b>TOTAL BIAYA YANG TELAH DIBAYAR</b></td>
			    	<td><b>Rp : <?= $code2['total'] ; ?></b></td>
			    </tr>
			  </tbody>
				</table>
				<table class="table table-bordered mt-4">
			  <thead class="thead-dark text-center">
			    <tr>
			      <th style="max-width: 40px !important;" scope="col">NO</th>
			      <th scope="col">BIAYA YANG HARUS DIBAYAR</th>
			      <th scope="col">JUMLAH</th>
			    </tr>
			  	</thead>
			  	<tbody>
			  		<?php $i = 1;?>
			  		<?php foreach ($data2 as $rows2): ?>
			    <tr>
			      <td class="text-center" style="max-width: 40px !important;"><?= $i; ?></td>
			      <td><?= $rows2['ket']; ?></td>
			      <td><?= $rows2['harga']; ?></td>
			    </tr>
			    <?php $i++; ?>
			    <?php endforeach; ?>
			    <tr>
			    	<td colspan="2"><b>TOTAL BIAYA YANG HARUS DIBAYAR</b></td>
			    	<td><b>Rp : <?= $code1['total'] ; ?></b></td>
			    </tr>
		    <tr>
		    	<td colspan="2"><b>TOTAL BIAYA TANGGUNGAN</b></td>
		    	<td><b>Rp : <?= $code3['total_all'] ; ?></b></td>
		    </tr>
		</tbody>
	</table>
</div>
</body>
</html>