<?php 

session_start();

require 'koneksi.php';
if (isset($_POST['login'])) {
	# code...
	$username = $_POST['username'];
	$password = $_POST['password'];

	$result= mysqli_query($conn,"SELECT * FROM login WHERE username = '$username' ");

	if ( mysqli_num_rows($result)===1)  {
		# code...
		$row = mysqli_fetch_assoc($result);
		if(password_verify($password, $row['password'])){
			$_SESSION['login'] = true;
			header('Location: admin.php');
			exit;
		}
	}

	$eror = true;
}
 ?>
<html>
<head>
	<title>LOGIN ADMIN</title>
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
<div class="login-bakground">
	<div class="container">
		<?php if (isset($eror)) :?>
			<center>
				<p class="text-white">USERNAME DAN PASSWORD SALAH </p>
			</center>
		<?php endif; ?>
		<div class="row justify-content-md-center">
			<div class="col col-12 col-sm-12 col-md-8 col-lg-4">
				<form method="post" action="">
					<div class="text-center">
					<img src="assets/img/data-diri.png">
					</div>
					<div class="form-group">
						<label>Username</label>
						<input placeholder="Masukan email atau user...." type="text" class="form-control" name="username">
					</div>
					<div class="form-group">
						<label>Password</label>
						<input placeholder="Masukan password....." type="password" class="form-control" name="password">
					</div>
					<div class="text-center">
					<button type="submit" name="login" class="btn btn-primary">Submit</button>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>
</body>
</html>