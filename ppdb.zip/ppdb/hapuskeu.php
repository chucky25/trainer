<?php 
session_start();
if (!isset($_SESSION['login'])) {
	# code...
	header('Location: login.php');
	exit;
}
require 'koneksi.php';
$id=$_GET['id'];

if (hapuskeu($id)>0) {
	# code...
	echo "
<script>
 	alert('BERHASIL DI HAPUS');
 	document.location.href='datasiswa.php';
 </script>
 ";
}
else{
	echo "
<script>
 	alert('TIDAK BERHASIL DI HAPUS');
 	document.location.href='index.php';
 </script>
 ";
}


 ?>