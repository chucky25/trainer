CREATE TABLE admin(
id CHAR (4) NOT NULL,
user_adm VARCHAR(16) NOT NULL,
pw_adm VARCHAR (30) NOT NULL
)
INSERT INTO admin VALUE ('1','admin','admin')